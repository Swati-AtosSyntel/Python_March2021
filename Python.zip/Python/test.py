# -*- coding: utf-8 -*-
"""
Created on Wed Mar 17 18:13:30 2021

@author: A719571
"""

from Addition import Total
import math as m
#result=Addition.Total(23,34)
result=Total(23,34)
print(result)
print(m.pi)