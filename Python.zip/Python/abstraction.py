# -*- coding: utf-8 -*-
"""
Created on Thu Mar 18 16:33:19 2021

@author: A719571
"""

import abc #abstarct base classes

class Animal(metaclass=abc.ABCMeta):
    @abc.abstractmethod#decorator
    def makeNoise(self):
        pass
#a=Animal()#gives error being Animal is an abstract class

class Dog(Animal):
    def makeNoise(self):
        print("In Dog class method")
        
class Cat(Animal):
    def makeNoise(self):
        print("In Cat class method")
        
class Horse(Animal):
    def makeNoise(self):
        print("In Horse class method")
animals=[Dog(),Cat(),Horse(),Cat()]

def processAnimalNoise(animal):
    print("animal:",type(animal))
    animal.makeNoise()

print("Processing Animal Noise....")

for animal in animals:
    processAnimalNoise(animal)
        
