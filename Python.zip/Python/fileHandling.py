# -*- coding: utf-8 -*-
"""
Created on Thu Mar 18 17:20:10 2021

@author: A719571
"""
import io

#==============================================================================
#==============================================================================
# fileptr=open("data.txt","w")
#  
# if(fileptr):
#      fileptr.write("Python is genral purpose language")
#      fileptr.flush();
#  
# fileptr=open("data.txt","a")
# fileptr.write("Python makes things simple")
#==============================================================================
 
fileptr=open("data.txt","r")
#==============================================================================
#==============================================================================
# text=fileptr.read(100)
# print(type(text))
# print(text)
#==============================================================================

text=fileptr.readlines()
print(text)
fileptr.close()
