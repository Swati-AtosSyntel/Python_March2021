# -*- coding: utf-8 -*-
"""
Created on Thu Mar 18 17:32:43 2021

@author: A719571
"""

import io

fileptr=open("data.txt","r")

print("The fileptr is at ",fileptr.tell())

fileptr.seek(20)
print("The fileptr after moving the filepointer is at ",fileptr.tell())
content=fileptr.read()

print(content)

print("The fileptr after reading file  is at ",fileptr.tell())

fileptr.close()