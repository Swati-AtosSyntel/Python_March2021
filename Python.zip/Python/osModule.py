# -*- coding: utf-8 -*-
"""
Created on Thu Mar 18 17:37:48 2021

@author: A719571
"""
import os
import io
#fileptr=open("file.txt","w")
#fileptr.close()
#os.remove("data.txt")
#os.rename("file.txt","python.txt")
os.remove("python.txt")

#os.mkdir("myFolder")
os.getcwd();
os.chdir("directory path")
os.rmdir("directory name")
