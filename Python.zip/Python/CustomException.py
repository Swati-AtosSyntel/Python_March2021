# -*- coding: utf-8 -*-
"""
Created on Thu Mar 18 17:04:09 2021

@author: A719571
"""
class AmountOverFlowError(Exception):
    def __init__(self,errorMessage):
        self.errorMessage=errorMessage

class Account:
    def deposit(self,amount):
        if(amount>50000):
            raise AmountOverFlowError("You can deposit max Rs.50000 only")
        print(10000+amount)

try:
    amt=int(input("Enter Amount"))
    acc=Account()
    acc.deposit(amt)
except AmountOverFlowError as e:
    print(e)
