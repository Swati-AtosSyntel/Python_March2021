# -*- coding: utf-8 -*-
"""
Created on Wed Mar 17 18:17:32 2021

@author: A719571
"""

class Employee:
    empid=123
    ename="Swati"
    location="Pune"
    
    def __init__(self):
        self.empid=300
        self.ename="Nilesh"
        self.location="Mumbai"
    
    def display(self):
        print(self.empid)
        print(self.ename)
        print(self.location)

e=Employee()

print(Employee.empid)
e.display()
        
   
    