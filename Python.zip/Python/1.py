# -*- coding: utf-8 -*-
"""
Created on Mon Mar 15 15:55:35 2021

@author: A719571
"""

a=10
print(a)
print(type(a))
print(a,end=" ")
print("Hello")
print("a=",a,sep='xxx',end="\n\n\n")
#name=input("Enter your name")
'''print(name)
x=int(input("Enter Number"))
print(type(x))'''

y=x

print(id(x))
print(id(y))
x=y=z=123
print(x)
print(y)
print(z)
print(id(x))
print(id(y))
print(id(z))


x,y,z=23,56,89
print (a)

s=''' This is multiline
text'''

print(s)

str="Hello World"
print(str[0])
print(str[-1])
print(str[2:7])

print(str[3:-2])

#str[3]="x"
str="This is m text"
print(str)
#del str[3] not supported
del s
#print(s)
##local and Global variables
a=20#global variable
def add():
    global a#local variable
    a=30
    print(id(a))
    print("Inside Function",a)

add()
print(id(a))
print("Outside Function=",a)

























