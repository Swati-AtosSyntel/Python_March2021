# -*- coding: utf-8 -*-
"""
Created on Wed Mar 17 17:13:46 2021

@author: A719571
"""
#Sets are collection of various data types  which is mutable, iterable and it has no duplicate values
#set can contain only immutable elements
mySet=set([1,"a",2,3])
print(mySet)
mySet.add("d")
print(mySet) 

set1={"Jan","Feb","Mar","April","Jan"}
set2={"May","June","July","April"}
set3={"April","September"}
print(set1)
#set2={1,2,["Jan","Feb","Mar"]}
#print(set2)

set3={}
set4=set();

#set1.update(["May","june","July","August"])
#print(set1)
set1.discard("September")
print(set1)

#set1.remove("September")
print(set1)
#set1.clear()
#print(set1)

#print(set1|set2)
#print(set1.union(set2))

#print(set1&set2)
set1.intersection_update(set1,set2)
print(set1)

a={"Devansh","Bob","Castle"}
b={"Castle","Dude","Smith"}
c={"Fuson","Gaurav","Castle"}

a.intersection_update(b,c)
print(a)

#dictionary
Dict={"id":1,"Name":"Swati"}
print(Dict)
Dict1=dict({"id":1,"Name":"Swati"})
Dict2=dict([(1,"Swati"),(2,"Nilesh")])
print(Dict2)
Dict[1]="Mitali"
print(Dict)
del Dict["id"]
print(Dict)
for i in Dict2.values():
    print(i)

for i,j in Dict2.items():
    print(i,j)

