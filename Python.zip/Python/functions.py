# -*- coding: utf-8 -*-
"""
Created on Wed Mar 17 17:57:57 2021

@author: A719571
"""
def add(a,b=20):
    return a+b
print(add(b=12,a=23))
print(add(12))

def updateList(list1):
    list1.append(20)
    list1.append(50)
    print("List inside Function:",list1)

list1=[10,30,40]

updateList(list1)

print("List Outside the function:",list1)

def updateText(string1):
    string1=string1+"World!!!"
    print(string1)

string1="Hello "
updateText(string1)
print(string1)

#**kwargs

def calcTotal(*nums):
    sum=0;
    print(type(nums))
    for i in nums:
        sum=sum+i
    print("sum=",sum)

calcTotal(20,30)
calcTotal(20,30,40)
calcTotal(20,30,50)
calcTotal(20,30,60)
    