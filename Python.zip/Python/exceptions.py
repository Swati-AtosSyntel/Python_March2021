# -*- coding: utf-8 -*-
"""
Created on Thu Mar 18 16:55:15 2021

@author: A719571
"""

try:
    n=int(input("Enter any number"))
    print("You have entered ",n)
    a=100/n
    print("a=",a)
    
    arr=[122,34454,667,899,67]
    print(arr[6])
except ZeroDivisionError as e:
    print("Dividing number by zero...",e)
except IndexError as e:
    print("Wrong Array Index...",e)
except Exception as e:
    print("Exception Ocurred")
else:
    print("No Exception ocurred")
finally:
    print("Completed Successfully...")
