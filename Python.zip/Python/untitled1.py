# -*- coding: utf-8 -*-
"""
Created on Mon Mar 15 17:06:39 2021

@author: A719571
"""
#list,tuple,dictionary,set,stack,queue
#lists are mutable
list1=[12,"Hi",2.3,"Python"]
list2=[20,30,40,50]
print(type(list1))
print(list1)
print(list1[2])
print(list1[2:])
print(list1[0:2])
print(list1+list2)

print(list1 *3)

list1[1]=200
print(list1)
del list1[1]
print(list1)

#list2.reverse()
#print(list2)
print(list(reversed(list2)))
print(list2)

#tuple
#tuples are immutable
#==============================================================================
# tuple1=(23,45,6,7,4.5,"Hi")
#  
# tuple2=34,5,6,7,9,"Hello"
#  
# print(tuple1)
# print(tuple2)
# 
# #tuple1[2]="Hi"
# 
# print(tuple1+tuple2)
# 
# tuple3=tuple1+tuple2
# print(tuple3)
# 
# for t in tuple1:
#     print(t)
# print("While Loop")
# a=0
# while(a<=10):
#     print(a)
#     a=a+2
#     
# n=range(0,10,2)
# for i in n:
#     print(i)
#     
# age=int(input("Enter Age"))
# 
# if(age<0):
#     print("age can not be negative")
# elif(age>=18):
#     print("eligible")
# else:
#     print("Hello")
#     
#     
#     
#     
#==============================================================================



