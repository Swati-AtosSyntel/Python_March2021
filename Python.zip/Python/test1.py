# -*- coding: utf-8 -*-
"""
Created on Wed Mar 17 18:25:34 2021

@author: A719571
"""
import oops

e1=oops.Employee()
e1.display()


