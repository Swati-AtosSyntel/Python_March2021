# -*- coding: utf-8 -*-
"""
Created on Wed Mar 17 18:12:54 2021

@author: A719571
"""
def Total(a,b):
    return a+b
    

