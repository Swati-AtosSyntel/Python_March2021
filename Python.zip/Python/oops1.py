# -*- coding: utf-8 -*-
"""
Created on Thu Mar 18 15:32:37 2021

@author: A719571
"""
class Employee:
    count=0#class variable
    eid=101#public
    _name="Aakash" #protected
    __salary=45000#private
#==============================================================================
#     def __init__(self):
#         print("In Constructor")
#         self.eid=int(input("Enter ID"))
#         self.ename=input("Enter name")
#         Employee.count=Employee.count+1
#==============================================================================
    def __init__(self,eid,name,salary):
        self.eid=eid
        self._name=name
        self.__salary=salary
    def display(self):
        print(self.eid,self._name,self.__salary)
        print("----------")

class Manager(Employee):
    def __init__(self,id,name,salary,reportees):
        super().__init__(id,name,salary)
        #Employee.__init__(self,id.name,salary)
        self.reportees=reportees
    def displayManagerDetails(self):
        self.display()
        print(self.reportees)
m1=Manager(123,"Ashish",67000,23)
m1.displayManagerDetails()
print(m1.__salary)

#==============================================================================
# emp1=Employee()
# emp2=Employee()
# emp3=Employee()
# 
# emp1.display()
# emp2.display()
# emp3.display()
# print(Employee.count)
# 
# print(getattr(emp1,'ename'))
# setattr(emp1,"ename","Ajay")
# print(getattr(emp1,'ename'))
# 
# print(hasattr(emp1,"ename"))
# delattr(emp1,"ename")
# 
# 
#==============================================================================
